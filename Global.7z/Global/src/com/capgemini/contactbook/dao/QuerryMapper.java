package com.capgemini.contactbook.dao;

public class QuerryMapper {
	public static final String VIEW_CONTACTBOOK_QUERRY = "SELECT firstName,lastName ,contactNo ,domain ,city  FROM enquiry WHERE  enqryId =?";
	public static final String INSERT_QUERY = "INSERT INTO enquiry VALUES(enquiries.NEXTVAL,?,?,?,?,?)";
	public static final String APPLYID_BOOKQUERRY_SEQUENCE = "SELECT enquiries.CURRVAL FROM DUAL";
}
