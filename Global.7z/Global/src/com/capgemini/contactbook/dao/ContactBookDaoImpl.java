package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {
	Logger logger = Logger.getRootLogger();

	public ContactBookDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");

	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getInstance().getConnection();

		PreparedStatement preparedst = null;
		ResultSet res = null;

		int enqryId = 0;

		int queryResult = 0;
		try {
			preparedst = connection.prepareStatement(QuerryMapper.INSERT_QUERY);

			preparedst.setString(1, enqry.getfName());
			preparedst.setString(2, enqry.getlName());
			preparedst.setString(3, enqry.getContactNo());
			preparedst.setString(4, enqry.getpLocation());
			preparedst.setString(5, enqry.getpDomain());

			queryResult = preparedst.executeUpdate();

			preparedst = connection
					.prepareStatement(QuerryMapper.APPLYID_BOOKQUERRY_SEQUENCE);
			res = preparedst.executeQuery();
			if (res.next()) {
				enqryId = res.getInt(1);

			}

			if (queryResult == 0) {
				logger.error("Insertion failed ");
				throw new ContactBookException(
						"INSERTING ENQUIRY DETAILS ARE FAILED");

			} else {
				logger.info("ENQUIRY DETAILS ARE  ADDED SUCCESSFULY...");
				return enqryId;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new ContactBookException(
					"TECHNICAL PROBLEM OCCURED REFER LOG");
		}

		finally {
			try {
				// resultSet.close();
				preparedst.close();
				connection.close();
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new ContactBookException("ERROR IN CLOSING DB CONNECTION");

			}
		}

	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getInstance().getConnection();

		PreparedStatement pst = null;
		ResultSet Result = null;
		EnquiryBean enquiry = null;

		try {
			pst = connection
					.prepareStatement(QuerryMapper.VIEW_CONTACTBOOK_QUERRY);
			pst.setInt(1, EnquiryID);
			Result = pst.executeQuery();

			if (Result.next()) {
				enquiry = new EnquiryBean();

				enquiry.setfName(Result.getString(1));
				enquiry.setlName(Result.getString(2));
				enquiry.setContactNo(Result.getString(3));
				enquiry.setpLocation(Result.getString(4));
				enquiry.setpDomain(Result.getString(5));

			}

			if (enquiry != null) {
				logger.info("RECORD FOUND SUCCESSFULY");
				return enquiry;
			} else {
				logger.info("RECORD NOT FOUND SUCCESSFULY");
				return null;
			}

		} catch (Exception exe) {
			logger.error(exe.getMessage());
			throw new ContactBookException(exe.getMessage());
		} finally {
			try {
				Result.close();
				pst.close();
				connection.close();
			} catch (SQLException exe) {
				logger.error(exe.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
	}

}
