package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService {
	ContactBookDao dao;

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub

		dao = new ContactBookDaoImpl();
		int sequence;
		sequence = dao.addEnquiry(enqry);
		return sequence;

	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		// TODO Auto-generated method stub
		dao = new ContactBookDaoImpl();
		EnquiryBean enquiry = null;
		enquiry = dao.getEnquiryDetails(EnquiryID);
		return enquiry;
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {

		List<String> validationErrors = new ArrayList<String>();

		// will c validateContactNo

		if (!validateContactNo(enqry.getContactNo()))
			validationErrors.add("contact no. should be of 10 digits");

		// validateFirstName(String fName)

		if (!validateFirstName(enqry.getfName()))
			validationErrors
					.add("First Name shouldn't be empty and should be alphabets only.");

		// validateLastName(String lName)

		if (!validateLastName(enqry.getlName()))
			validationErrors
					.add("Last Name shouldn't be empty and should be alphabets only.");

		// validatePLocation(String pLocation)

		if (!validatePLocation(enqry.getpLocation()))
			validationErrors
					.add("Location shouldn't be empty and should be alphabets only.");

		// calls validatePDomain(String pDomain)

		if (!validatePDomain(enqry.getpDomain()))
			validationErrors
					.add("Domain shouldn't be empty and should be alphabets only.");

		if (!validationErrors.isEmpty())
			throw new ContactBookException(validationErrors + "");
		return true;
	}

	public boolean checkEnquiryId(int enquiryId) {
		if (enquiryId >= 1001 && enquiryId <= 9999)
			return true;
		else
			return false;
	}

	public boolean validateContactNo(String contactNo) {

		Pattern phonePattern = Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher = phonePattern.matcher(contactNo);
		return phoneMatcher.matches();

	}

	public boolean validateFirstName(String fName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{1,}$");
		Matcher nameMatcher = namePattern.matcher(fName);
		return nameMatcher.matches();

	}

	public boolean validateLastName(String lName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{1,}$");
		Matcher nameMatcher = namePattern.matcher(lName);
		return nameMatcher.matches();

	}

	public boolean validatePLocation(String pLocation) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{1,}$");
		Matcher nameMatcher = namePattern.matcher(pLocation);
		return nameMatcher.matches();

	}

	public boolean validatePDomain(String pDomain) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{1,}$");
		Matcher nameMatcher = namePattern.matcher(pDomain);
		return nameMatcher.matches();

	}
}