package com.capgemini.contactbook.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;

public class Client {
	static Scanner sc = new Scanner(System.in);
	static ContactBookService contactbookservice = null;
	static ContactBookServiceImpl contactbookserviceimpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws ContactBookException {
		PropertyConfigurator.configure("resources//log4j.properties");
		EnquiryBean b1 = null;

		int enqryId = 0;
		int option = 0;
		while (true) {
			System.out.println("1.Add Details ");
			System.out.println("2.View Details");

			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");

			option = sc.nextInt();

			switch (option) {
			case 1:

				EnquiryBean bean = new EnquiryBean();

				System.out.println("\n Enter Details");

				System.out.println("Enter first name: ");
				bean.setfName(sc.next());

				System.out.println("Enter last name: ");
				bean.setlName(sc.next());

				System.out.println("Enter contact number: ");
				bean.setContactNo(sc.next());
				System.out.println("Enter location: ");
				bean.setpLocation(sc.next());
				System.out.println("Enter domain: ");
				bean.setpDomain(sc.next());

				try {
					contactbookservice = new ContactBookServiceImpl();
					enqryId = contactbookservice.addEnquiry(bean);

					System.out.println("Thank you " + bean.getfName() + " "
							+ bean.getlName() + " Your unique id is" + enqryId);

				} catch (Exception e) {

					e.printStackTrace();

				} finally {
					enqryId = 0;
					contactbookservice = null;
					bean = null;
				}

				break;
			case 2:

				contactbookserviceimpl = new ContactBookServiceImpl();

				System.out.println("Enter numeric donor id:");
				enqryId = sc.nextInt();

				b1 = contactbookserviceimpl.getEnquiryDetails(enqryId);

				if (b1 != null) {
					System.out.println("FirstName      :" + b1.getfName());
					System.out.println("lastName       :" + b1.getlName());
					System.out
							.println("contactNumber     :" + b1.getContactNo());
					System.out.println("location      :" + b1.getpLocation());
					System.out.println("Domain :" + b1.getpDomain());

				} else {
					System.err
							.println("There is no location details associated with enquiry id "
									+ enqryId);
				}

				break;
			case 3:
				System.out.print("Exit Trust Application");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option[1-4]");
			}// end
		}
	}

}
