package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoTest {
	static ContactBookDaoImpl dao;
	static EnquiryBean enquiry;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new ContactBookDaoImpl();
		enquiry = new EnquiryBean();
	}

	@Test
	public void testAddEnquiry() throws ContactBookException {

		assertNotNull(enquiry);

	}

	/************************************
	 * Test case for addEnquiry()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddAddEnquiry1() throws ContactBookException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addEnquiry(enquiry));
	}

	/************************************
	 * Test case for addEnquiry()
	 * 
	 ************************************/

	@Test
	public void testaddEnquiry2() throws ContactBookException {

		enquiry.setfName("Ranbir");
		enquiry.setlName("Gupta");
		enquiry.setpDomain("java");
		enquiry.setContactNo("1236547895");
		enquiry.setpLocation("Pune");
		System.out.println("Data inserted successfully");
		
		assertTrue("Data Inserted successfully",
				(dao.addEnquiry(enquiry)) > 1000);

	}


	/****************************************************
	 * Test case for getEnquiryDetails()
	 ******************************************************/

	@Test
	public void testGetEnquiryDetails() throws ContactBookException {
		assertNotNull(dao.getEnquiryDetails(1001));
	}

	@Ignore
	@Test
	public void testGetEnquiryDetails1() throws ContactBookException {
		assertEquals("Ranbir", dao.getEnquiryDetails(1001).getfName());
	}

}
